//
//  APIManager.swift
//  TC User APP
//
//  Created by Kavin on 01/12/20.
//  Copyright © 2020 Imcrinox. All rights reserved.
//


import UIKit

var isAppExpired = false

enum APIURLType: String {
    
    case liveApi = "https://daallo.com/api/flight/"




    var baseUrl: String {
        return self.rawValue
    }
}
enum APIPath: String {
    
  case calendarAPI = "calendar?From=DXB&To=MGQ"
    
    func directURL(type: APIURLType) -> URL? {
        let urlPath = type.baseUrl + self.rawValue
        return URL(string: urlPath)
    }
    
    func extendedURL(type: APIURLType, attach path: String) -> URL? {
        let urlPath = type.baseUrl + self.rawValue + "?" + path
        return URL(string: urlPath)
    }
    
    func extendedURL(type: APIURLType, using parameters: [String:String]) -> URL? {
        let urlPath = parameters.reduce(type.baseUrl + self.rawValue) { (urlPath, parameter) -> String in
            return urlPath + "?" + parameter.key + "=" + parameter.value
        }
        return URL(string: urlPath)
    }
    
}

enum APIMethod: String {
    case get = "GET"
    case put = "PUT"
    case post = "POST"
    case patch = "PATCH"
    case delete = "DELETE"
}

enum APIHeaders {
    case withToken
    case withoutToken
    
    var authorization: [String:String] {
        switch self {
        case .withoutToken:
            return ["Content-Type":"application/json","Authentication" : "","Token":"","Accept-Language":"en","app":"1"]
        case .withToken:
            let getAuthKey = UserDefaults.standard.object(forKey: "access_token") as? String ?? ""
            return ["Content-Type":"application/json","Accept-Language":"en","Token":getAuthKey,"app":"1"]
        }
    }
}

struct APIRequest {
    
    var url: URL?
    var method: String
    var parameters: Data?
    var headers: [String:String]
    
    init(urlType: APIURLType = .liveApi, path: APIPath, method: APIMethod, headers: APIHeaders) {
        self.url = path.directURL(type: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
    
    init(urlType: APIURLType = .liveApi, path: APIPath, attachLastPath lastPath: String, method: APIMethod, headers: APIHeaders) {
        self.url = path.extendedURL(type: urlType, attach: lastPath)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
    
    init(urlType: APIURLType = .liveApi, path: APIPath, attachParameters parameters: [String:String], method: APIMethod, headers: APIHeaders) {
        self.url = path.extendedURL(type: urlType, using: parameters)
        #if DEBUG
            print(self.url?.absoluteString as Any)
            print(JSON(parameters))
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
    
    init(urlType: APIURLType = .liveApi, path: APIPath, method: APIMethod, parameters: [String:Any], headers: APIHeaders) {
        self.url = path.directURL(type: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
            print(JSON(parameters))
        #endif
        self.method = method.rawValue
        self.parameters = try? JSONSerialization.data(withJSONObject: parameters, options: .sortedKeys)
        self.headers = headers.authorization
    }
    
    init<Encode: Encodable>(urlType: APIURLType = .liveApi, path: APIPath, method: APIMethod, parameters: Encode, headers: APIHeaders) {
        self.url = path.directURL(type: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.parameters = try? JSONEncoder().encode(parameters)
        self.headers = headers.authorization
    }

    init(urlType: String, method: APIMethod, headers: APIHeaders) {
        self.url = URL(string: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
}


struct APIError: Error {
    let reason: String
    init(reason: String) {
        self.reason = reason
    }
}


struct APIDispatcher {
    
    static let instance = APIDispatcher()
    private init() {}
    
    func dispatch<Decode: Decodable>(request: APIRequest, response: Decode.Type, result: @escaping (Result<Decode, APIError>) -> ()) {
        self.connectToServer(with: request) { (resultant) in
            switch resultant {
            case .success(let data):
                do {
                    let decoded = try JSONDecoder().decode(response, from: data)
                    DispatchQueue.main.async {
                        result(.success(decoded))
                    }
                } catch {
                    let apiError = APIError(reason: error.localizedDescription)
                    DispatchQueue.main.async {
                        result(.failure(apiError))
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    result(.failure(error))
                }
            }
        }
    }
    
    func dispatch(request: APIRequest, result: @escaping (Result<Dictionary<String,Any>, APIError>) -> ()) {
//        if !isInternetReachable() {
//            self.showInternetView()
//            return
//        }
        self.connectToServer(with: request) { (resultant) in
            switch resultant {
            case .success(let data):
                do {
                    if let serialized = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String,Any> {
                        DispatchQueue.main.async {
                            result(.success(serialized))
                        }
                    } else {
                        let apiError = APIError(reason: "No Data as Dictionary<String, Any>")
                        DispatchQueue.main.async {
                            result(.failure(apiError))
                        }
                    }
                } catch {
                    let error = APIError(reason: error.localizedDescription)
                    DispatchQueue.main.async {
                        result(.failure(error))
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    result(.failure(error))
                }
            }
        }
    }
    
    private func connectToServer(with request: APIRequest, result: @escaping (Result<Data, APIError>) -> ()) {
        guard let url = request.url else {
            let error = APIError(reason: "Invalid URL")
            result(.failure(error))
            return
        }
        let getUrlStr = request.url?.absoluteString as? String ?? ""
        var showLoader = true
//        if getUrlStr.contains("home_page.php"){
//            showLoader = false
//        }else if getUrlStr.contains("add_ons_list.php"){
//            showLoader = false
//        }else if getUrlStr.contains("get_profile.php"){
//            showLoader = false
//        }else if getUrlStr.contains("remider.php"){
//            showLoader = false
//        }else if getUrlStr.contains("push.php"){
//            showLoader = false
//        }
//        if showLoader{
//            self.showLoading()
//        }
        
        print("API : ", url)
        print("Body : ")
        var urlRequest = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 30)
        urlRequest.httpMethod = request.method
        urlRequest.httpBody = request.parameters
        urlRequest.allHTTPHeaderFields = request.headers
        let getAuthKey = UserDefaults.standard.object(forKey: "access_token") as? String ?? ""
        if !getAuthKey.isEmpty{
            urlRequest.addValue("Bearer \(getAuthKey)", forHTTPHeaderField: "Authorization")
        }
        let urlSessionConfiguration = URLSessionConfiguration.default
        urlSessionConfiguration.waitsForConnectivity = true
        urlSessionConfiguration.timeoutIntervalForRequest = 30
        urlSessionConfiguration.timeoutIntervalForResource = 60
        
        let urlSession = URLSession(configuration: urlSessionConfiguration)
        urlSession.dataTask(with: urlRequest) { (data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                print("Status Code: " + "\(httpResponse.statusCode)")
            }
//            if !getUrlStr.contains("home_page.php") || !getUrlStr.contains("add_ons_list.php"){
                self.removeLoading()
//            }
            guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
                var errorDescription = ""
                if let httpResponse = response as? HTTPURLResponse {
                    if httpResponse.statusCode == 503{
                        isAppExpired = true
                        DispatchQueue.main.async {
//                            if let topVC = UIApplication.topViewController() {
//                                topVC.showSimpleAlert(withTitle: "Session expired. Please login to continue", vc: topVC, type: 15)
//                            }
                        }
                        return
                    }
                    errorDescription = ("Status Code: " + httpResponse.statusCode.description + "\n")
                }
                if let data = data, let errorResponse = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String, Any> {
                    errorDescription += (errorResponse.compactMap({ (key, value) -> String in
                        return key + ": " + (value as? String ?? "")
                    })).joined(separator: "\n")
                }
                let apiError = APIError(reason: errorDescription)
                result(.failure(apiError))
                return
        }
            
            if let error = error {
                let apiError = APIError(reason: error.localizedDescription)
                result(.failure(apiError))
                return
            }
            if let data = data {
                if let serialized = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String, Any>, serialized.contains(where: { $0.key == "error" }), let errorText = ((serialized["message"] as? String) ?? serialized["error"] as? String) {
                    let apiError = APIError(reason: errorText)
                    result(.failure(apiError))
                    return
                }
                result(.success(data))
            }
        }.resume()
        
    }
    func showLoading() {
        DispatchQueue.main.async {
//            if let topVC = UIApplication.topViewController() {
//                let loadingView = UIView(frame: topVC.view.bounds)
//                loadingView.tag = 999
//                loadingView.accessibilityIdentifier = "loading_view"
//                loadingView.backgroundColor = .clear//UIColor.white.withAlphaComponent(0.5)
//                let activityIndicatorView = UIActivityIndicatorView(style: .white)
//                activityIndicatorView.center = loadingView.center
//                activityIndicatorView.color = UIColor(displayP3Red: 48/255, green: 31/255, blue: 101/255, alpha: 1)
//                activityIndicatorView.startAnimating()
//                loadingView.addSubview(activityIndicatorView)
//                topVC.view.insertSubview(loadingView, at: 999)
//            }
        }
    }
    func removeLoading() {
        DispatchQueue.main.async {
//            if let topVC = UIApplication.topViewController() {
//                if let loadingView = topVC.view.subviews.first(where: { $0.tag == 999 && $0.accessibilityIdentifier == "loading_view" }) {
//                    loadingView.removeFromSuperview()
//                }
//            }
        }
    }
    func showInternetView(){
        DispatchQueue.main.async {
//            if let topVC = UIApplication.topViewController() {
//                topVC.showToast(message: "No internet connection", isError: true)
//            }
        }
    }
}
//extension UIApplication {
//    class func topViewController(_ viewController: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
//        if let nav = viewController as? UINavigationController {
//            return topViewController(nav.visibleViewController)
//        }
//        if let tab = viewController as? UITabBarController {
//            if let selected = tab.selectedViewController {
//                return topViewController(selected)
//            }
//        }
//        if let presented = viewController?.presentedViewController {
//            return topViewController(presented)
//        }
//        return viewController
//    }
//}
