//
//  ControllerExtension.swift
//  Bloss

//  Created by IMCRINOX on 05/04/22.
//

import Foundation
import UIKit
//import SDWebImage
var isSessionExpired = false
//var userLoggedInfo = ProfileResponse.init(fromDictionary: [String : Any]())

extension UIViewController:UIGestureRecognizerDelegate{
    func dismissVC(){
        mainThread {
            self.dismiss(animated: true, completion: nil)
        }
    }
    func popVC(){
        mainThread {
            self.navigationController?.popViewController(animated: true)
        }
    }
    func getControllerId(_ identifier:String) -> UIViewController?{
        let vc = self.storyboard?.instantiateViewController(withIdentifier:identifier)
//        vc?.modalPresentationStyle = .overFullScreen
        return vc
    }
    func presentController(_ vc:UIViewController){
        mainThread {
            self.present(vc, animated: true, completion: nil)
        }
    }
    func pushController(_ vc:UIViewController){
        mainThread {
            self.navigationController?.interactivePopGestureRecognizer?.delegate = self
            self.tabBarController?.navigationItem.hidesBackButton = true
            self.navigationController?.isNavigationBarHidden = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    func mainThread(_ function: @escaping ()->())
    {
        DispatchQueue.main.async(execute: function)
    }
    func setRootController(identifier:String){
        mainThread {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let mainViewController = storyboard.instantiateViewController(withIdentifier: identifier)
            let nav = UINavigationController.init(rootViewController: mainViewController)
//            nav.interactivePopGestureRecognizer?.delegate = self
            nav.isNavigationBarHidden = true
            UIApplication.shared.windows.first?.rootViewController = nav
            UIApplication.shared.windows.first?.makeKeyAndVisible()
        }
    }
    func showYesnoAlertWithClosure(title:String,type:Int,vc:UIViewController,completionHandler: @escaping (Bool) -> Void){
//        DispatchQueue.main.async {
//            self.showTSAlert(title, "Yes", "No", type) { isCancelled, tag in
//                completionHandler(!isCancelled)
//            }
//            let setupViewController = CompactExampleViewConroller()
//            setupViewController.showAlertPage(message: NSLocalizedString(title, comment: ""), alertTag: type, showCancelButton: true, showSubmitButton: true, yesTitle: NSLocalizedString("Yes", comment: ""), noTitle: NSLocalizedString("No", comment: "")) { (status, tag, isActionSheet) in
//                if status{
//                    completionHandler(status)
//                }else {
//                    completionHandler(status)
//                }
//                setupViewController.dismiss(animated: true, completion: nil)
//            }
//            let actionPickerViewController = AlertViewController(contentViewController: setupViewController)
//            vc.present(actionPickerViewController, animated: false, completion: nil)
//        }
    }
    func showForceAlert(link:String,msg:String){
        DispatchQueue.main.async {
//            self.showTSAlert(msg, "OK", "", 0) { isCancelled, tag in
//                if !isCancelled{
//                    self.openBrowser(urlString: link)
//                }
            }
        }
    }
//    func showSimpleAlert(withTitle title: String,vc:UIViewController,type:Int) {
//        if isSessionExpired && type == 15{
//            return
//        }
//        if type == 15{
//            isSessionExpired = true
//        }
////        DispatchQueue.main.async {
//            self.showTSAlert(title, "Ok", "", type) { isCancelled, tag in
//                if !isCancelled{
//                    if tag == 5{
//                        self.dismissVC()
//                    }else if tag == 10{
//                        self.setRootController(identifier: NavigationHelper.homeVC)
//                    }else if tag == 15{
//                        isSessionExpired = false
//                        let getLangauge = L102Language.currentAppleLanguage()
//                        UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
//                        UserDefaults.standard.synchronize()
//                        L102Language.setAppleLAnguageTo(lang: getLangauge)
//                        SDImageCache.shared.clearMemory()
//                        SDImageCache.shared.clearDisk()
//                        self.setRootController(identifier: "ViewController")
//                    }else if tag == 20{
//                        self.popVC()
//                    }
//                }
//            }
//            /*let setupViewController = CompactExampleViewConroller()
//            setupViewController.showAlertPage(message: NSLocalizedString(title, comment: ""), alertTag: type, showCancelButton: false, showSubmitButton: true, yesTitle: NSLocalizedString("OK", comment: ""), noTitle: "") { (status, tag, isActionSheet) in
//                if status{
//                    if tag == 5{
//                        self.dismissVC()
//                    }else if tag == 10{
//                        self.setRootController(identifier: NavigationHelper.homeVC)
//                    }else if tag == 15{
//                        isSessionExpired = false
//                        let getLangauge = L102Language.currentAppleLanguage()
//                        UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
//                        UserDefaults.standard.synchronize()
//                        L102Language.setAppleLAnguageTo(lang: getLangauge)
//                        SDImageCache.shared.clearMemory()
//                        SDImageCache.shared.clearDisk()
//                        self.setRootController(identifier: "ViewController")
//                    }
//                }
//                setupViewController.dismiss(animated: true, completion: nil)
//            }
//            self.showCustomPopup(controller: setupViewController)*/
////        }
//    }
//    func showCustomPopup(controller:UIViewController){
//        let actionPickerViewController = AlertViewController(contentViewController: controller)
//        actionPickerViewController.hidesBottomBarWhenPushed = true
//        self.present(actionPickerViewController, animated: false, completion: nil)
//    }
//    func triggerProfileAPI(){
//        let token = self.retriveUserDefaults("user_token")
//        if token.isEmpty{
//            return
//        }
//        let apiRequest = APIRequest(path: .getProfileAPI, method: .get, headers: .withToken)
//          APIDispatcher.instance.dispatch(request: apiRequest) { (result) in
//              self.triggerPushAPI()
//              switch result {
//              case .success(let response):
//                  print(JSON(response))
//                  let modal = ProfileModal.init(fromDictionary: response)
//                  userLoggedInfo = modal.response
//              case .failure(let apiError):
//                  print(apiError.localizedDescription)
//              }
//          }
//    }
//    fileprivate func triggerPushAPI() {
//        let param = ["token":deviceID,
//                     "device_type":"2",
//                     "uuid":UUID().uuidString,
//                     "system_info":UIDevice().type.rawValue]
//        print(JSON(param))
//        let apiRequest = APIRequest(path: .pushAPI, method: .post, parameters: param, headers: .withToken)
//        APIDispatcher.instance.dispatch(request: apiRequest) { (result) in
//            switch result {
//            case .success(let response):
//                print(response)
//            case .failure(let apiError):
//                print(apiError.localizedDescription)
//            }
//        }
//    }
//    public func gestureRecognizerShouldBegin(gestureRecognizer: UIGestureRecognizer!) -> Bool {
//        return true
//    }
////    public func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldBeRequiredToFailBy otherGestureRecognizer: UIGestureRecognizer) -> Bool {
////           return true
////       }
//}
//
