//
//	ModelFrom.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation


class ModelFrom : NSObject, NSCoding{

	var dAY : String!
	var from : String!
	var to : String!
	var id : String!


	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		dAY = dictionary["DAY"] as? String
		from = dictionary["From"] as? String
		to = dictionary["To"] as? String
		id = dictionary["_id"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if dAY != nil{
			dictionary["DAY"] = dAY
		}
		if from != nil{
			dictionary["From"] = from
		}
		if to != nil{
			dictionary["To"] = to
		}
		if id != nil{
			dictionary["_id"] = id
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         dAY = aDecoder.decodeObject(forKey: "DAY") as? String
         from = aDecoder.decodeObject(forKey: "From") as? String
         to = aDecoder.decodeObject(forKey: "To") as? String
         id = aDecoder.decodeObject(forKey: "_id") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if dAY != nil{
			aCoder.encode(dAY, forKey: "DAY")
		}
		if from != nil{
			aCoder.encode(from, forKey: "From")
		}
		if to != nil{
			aCoder.encode(to, forKey: "To")
		}
		if id != nil{
			aCoder.encode(id, forKey: "_id")
		}

	}

}