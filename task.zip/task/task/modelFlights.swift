//
//  modelFlights.swift
//  task
//
//  Created by Imcrinox Mac on 02/11/23.
//

import Foundation

class FlightScheduleResponse: Codable {
    var to: [FlightSchedule]?
    var from: [FlightSchedule]?
}

class FlightSchedule: Codable {
    var id: String?
    var day: String?
    var from: String
    var to: String

 
}
