//
//  oneVC.swift
//  task
//
//  Created by Imcrinox Mac on 31/10/23.
//

import UIKit
import FSCalendar
class oneVC: UIViewController, FSCalendarDataSource, FSCalendarDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate  {
    
    
    @IBOutlet weak var calendar: FSCalendar!
    
    
    @IBOutlet weak var leftMove: UIButton!
    
    
    @IBOutlet weak var rightMove: UIButton!
    
    
    @IBOutlet weak var textBox: UITextField!
    
    @IBOutlet weak var dropDown: UIPickerView!
    
   
    
    var list = ["johnn", "ravi", "kanna", "pankaj" ]
    override func viewDidLoad() {
        super.viewDidLoad()
        let calendar = FSCalendar(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
        calendar.dataSource = self
        calendar.delegate = self
        
                calendar.setCurrentPage(Date(), animated: true)

        self.calendar = calendar
        // Do any additional setup after loading the view.
    }
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        let currentDate = Date()
        let calendarStartDate = Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: currentDate))!


        return Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: currentDate))!
    }
    
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool) {
        
    }
    
    
//    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
//        
//    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func backward(_ sender: Any) {
        print("####")
       
//        let currentMonth = Calendar.current.component(.month, from: Date())
//
//        if let currentPage = calendar.currentPage {
//            let pageMonth = Calendar.current.component(.month, from: currentPage)
//
//            if pageMonth != currentMonth {
//                calendar.setCurrentPage(Date(), animated: true)
//            }
//        }
    }
    
    @IBAction func forward(_ sender: Any) {
        print("$$$$")
      
//        if let currentPage = calendar.currentPage {
//
//            let next
//        }
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return list.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        return list[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.textBox.text = self.list[row]
        self.dropDown.isHidden = true
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.textBox {
            self.dropDown.isHidden = false
            textField.endEditing(true)
        }
    }

    @IBAction func enterBtn(_ sender: Any) {
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // You can change the date format as per your requirement
        let selectedDate = dateFormatter.string(from: date)
        
        // Now 'selectedDate' contains the selected date in the desired format.
        
        // You can use the 'selectedDate' variable in your code as needed, for example, print it.
        print("Selected Date: \(selectedDate)")
    }

    
    
    
}
