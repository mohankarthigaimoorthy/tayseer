//
//  ViewController.swift
//  task
//
//  Created by Imcrinox Mac on 31/10/23.
//

import UIKit
import FSCalendar

struct FlightDay {
    var day: String
    var from: String
    var to: String
}



class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate, FSCalendarDataSource, FSCalendarDelegate {
    

    @IBOutlet weak var bgOne: UIView!
   
    @IBOutlet weak var textFieldOne: UITextField!
    
    
    @IBOutlet weak var pickerOne: UIPickerView!
    
    
    @IBOutlet weak var textFieldTwo: UITextField!
    
    @IBOutlet weak var swapBtn: UIButton!
    
    
    @IBOutlet weak var pickerTwo: UIPickerView!
    
    
    @IBOutlet weak var textFieldThree: UITextField!
    
    @IBOutlet weak var textFieldFour: UITextField!
    
    
    @IBOutlet weak var entryBtn: UIButton!
    
    @IBOutlet weak var calendar: FSCalendar!
    
    @IBOutlet weak var calendarTwo: FSCalendar!
    
    var flightDays: [FlightDay] = [] // This array will store the flight days obtained from the API response

    var cites = ["Dubai (DXB)", "Bosaso (BSA)", "Mogadhishu (MGQ)","Hargesia (HGA)","Jeddah (JED)","Nairobi (NBO)","Garowe (GGR)"]

    var flightpage = Modelflight.init(fromDictionary: [String : Any]())
    var remo : [ModelFrom] = []
    
    var changeCount = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        calendar.delegate = self
        calendar.dataSource = self
        
        calendarTwo.delegate = self
        calendarTwo.dataSource = self
        // Do any additional setup after loading the view.
//        triggerAPI()
        
//        calendar.scope = .month
//        calendar.setScope(.week, animated: true)
        
        let particularDate = Calendar.current.date(bySetting: .day, value: 15, of: Date())!
        let year = Calendar.current.component(.year, from: particularDate)
        let month = Calendar.current.component(.month, from: particularDate)
        calendar.setCurrentPage(particularDate, animated: true)

        textFieldOne.placeholder = "From"
        textFieldTwo.placeholder = "To"
        textFieldThree.placeholder = "Depature Date"
        textFieldFour.placeholder = "Return Date"
    }

    @IBAction func swappedBtn(_ sender: Any) {
        
        if let texttone = textFieldOne.text ,let texttwo = textFieldTwo.text {
            textFieldOne.text = texttwo
            textFieldTwo.text = texttone
        }
        
    }
    
    
    @IBAction func enterBtn(_ sender: Any) {
//        triggerAPI()
    }
    
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
           let calendar = Calendar.current
           let components = calendar.dateComponents([.year, .month], from: date)
           guard let month = components.month else { return 0 }
           guard let year = components.year else { return 0 }

           // Check if the day is in the current month or a future month
           for flightDay in flightDays {
               if flightDayMatchesDate(flightDay, month: month, year: year) {
                   return 1
               }
           }
           return 0
       }
    
    
    func flightDayMatchesDate(_ flightDay: FlightDay, month: Int, year: Int) -> Bool {
        // Get the current calendar
        let calendar = Calendar.current
        
        // Get the day of the week for the flightDay
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE" // "EEE" represents the abbreviated day of the week like "MON", "TUE", etc.
        guard let flightDayDate = dateFormatter.date(from: flightDay.day) else {
            return false
        }
        
        // Get the components from the flightDay
        let flightDayComponents = calendar.dateComponents([.day, .month, .year], from: flightDayDate)
        
        // Check if the flightDay is in the same month and year as the current date
        if flightDayComponents.month == month && flightDayComponents.year == year {
            // Compare the day of the week
            let currentDate = Date()
            let currentDayOfWeek = calendar.component(.weekday, from: currentDate) // 1 is Sunday, 2 is Monday, and so on
            
            // Convert flightDay's day of the week to numeric representation
            let flightDayOfWeek = calendar.component(.weekday, from: flightDayDate)
            
            // Compare the day of the week and return true if they match
            return currentDayOfWeek == flightDayOfWeek
        }
        
        return false
    }

    
    
    func calendar(_ calendar: FSCalendar, subtitleFor date: Date) -> String? {
        return nil
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return cites.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        return cites[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == pickerOne {
            self.textFieldOne.text = self.cites[row]
            self.pickerOne.isHidden = true
        }
        else if pickerView == pickerTwo {
            self.textFieldTwo.text = self.cites[row]
            self.pickerTwo.isHidden = true
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        changeCount += 1
        print("textFieldDidBeginEditing called")

        if textField == self.textFieldOne {
            self.pickerOne.isHidden = false
            textField.endEditing(true)
        }
        else if textField == self.textFieldTwo {
            self.pickerTwo.isHidden = false
            textField.endEditing(true)
        }
        else if textField == self.textFieldThree {
            calendar.isHidden = false
            textField.endEditing(true)
        }
        else if textField == self.textFieldFour {
            calendarTwo.isHidden = false
            textField.endEditing(true)
        }
        
        if let from = textFieldOne.text,
           let to = textFieldTwo.text, !from.isEmpty, !to.isEmpty {
               // Call the triggerAPI function
               triggerAPI()
           }
    }
    
//MARK: - Api calling
    func triggerAPI() {
        let apirequest = APIRequest(path: .calendarAPI, method: .get
                                    , headers: .withToken)
        APIDispatcher.instance.dispatch(request: apirequest) { (result) in
            switch result {
            case .success(let response):
                print(JSON(response))
                let modal = Modelflight(fromDictionary: response)
//                if modal.from != nil {
                    self.remo =  modal.from
                    if let fromdata = modal.from.first, let toData = modal.to.first {
                        if let fromindex = self.cites.index(of: fromdata.from), let toindex = self.cites.index(of: toData.to) {
                            DispatchQueue.main.async {
                                self.textFieldOne.text = self.cites[fromindex]
                                self.textFieldTwo.text = self.cites[toindex]
                            }
                        }
                        else {
                            print("Airport codes not found in the 'cites' array.")

                        }
                    }
                    
                    if modal.from.first != nil {
                        DispatchQueue.main.async {
                            self.calendar.reloadData()
                        }
                    }
                    print("\(self.remo)")
//                }
            case .failure(let apiError):
                print(apiError.localizedDescription)
            }
        }
    }
    
    func parseFlightDays(response: [String: Any]) {
        if let fromArray = response["from"] as? [[String: Any]] {
            for dayData in fromArray {
                if let day = dayData["DAY"] as? String,
                   let from = dayData["From"] as? String,
                   let to = dayData["To"] as? String {
                    let flightDay = FlightDay(day: day, from: from, to: to)
                    flightDays.append(flightDay)
                    print("Flight Days: \(flightDay)")
                }
            }
        }
    }

//MARK: - did selected item
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
           let dateFormatter = DateFormatter()
           dateFormatter.dateFormat = "dd-MM-yyyy"
           let selectedDate = dateFormatter.string(from: date)
           
           if calendar == self.calendar {
               // Assign selected date from the first calendar to textFieldThree
               textFieldThree.text = selectedDate
           } else if calendar == self.calendarTwo {
               // Assign selected date from the second calendar to textFieldFour
               textFieldFour.text = selectedDate
           }
           
           // Hide the respective calendar after selecting a date
           calendar.isHidden = true
           calendarTwo.isHidden = true
       }
    
    
}

